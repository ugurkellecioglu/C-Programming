#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int id; // book id
    char name[20]; // book name
    char author[20]; // author of book
    int quantity; // quantity of book
    int rackno; // rack no of the book
} bookData;

void showRecords();
int updateRecord(int id, int diff);
int deleteRecord(int id);

int main()
{
    int id;
    int diff;

    printf("\nBooks:\n");
    showRecords();

    printf("\nEnter id of the book to be updated: ");
    scanf("%d",&id);
    printf("How many books will be added(+) or removed(-): ");
    scanf("%d",&diff);

    if (updateRecord(id, diff) == 0)
        printf("There is no book with id %d\n",id);

    printf("\nBooks:\n");
    showRecords();

    printf("\nEnter id of the book to be deleted: ");
    scanf("%d",&id);

    if (deleteRecord(id) == 0)
        printf("There is no book with id %d\n",id);

    printf("\nBooks:\n");
    showRecords();

    return 0;
}

void showRecords()
{
    // implement here
}


int updateRecord(int id, int diff)
{
    // implement here
}

int deleteRecord(int id)
{
    // implement here
}
