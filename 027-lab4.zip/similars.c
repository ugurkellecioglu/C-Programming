//
//  main.c
//  ted_lab_3b
//
//  Created by Kasim Oztoprak on 29.04.2021.
//

//
//  main.c
//  ted_lab
//
//  Created by Kasim Oztoprak on 27.04.2021.
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define STR_LEN 20
#define MAX_ELEM 10

void print_map (char item[MAX_ELEM][STR_LEN],int map[MAX_ELEM][MAX_ELEM],int param) ;
void strong_similar (char list[MAX_ELEM][STR_LEN], int map[MAX_ELEM][MAX_ELEM]) ;
void weak_similar (char list[MAX_ELEM][STR_LEN], int map[MAX_ELEM][MAX_ELEM]) ;

int main()
{

    unsigned int same[MAX_ELEM][MAX_ELEM];
    //char list[MAX_ELEM][STR_LEN] = {"ahmet yuksel", "mehmet arslan", "mustafa kemal", "ali kemal", "mustafa kemal", "mustafa kemal",
    //"mehmet arslan", "kemal ahmet", "ali kaan", "kemal kaan"};
    char list[MAX_ELEM][STR_LEN];
    printf("Enter 10 elements:\n");
    int i = 0;
    for(i = 0; i < MAX_ELEM; i++){
        scanf("%[^\n]%*c", list[i]);
    }
    // calculate  strong similarities
    strong_similar (list, same) ;
    print_map (list,same,1) ;

    // calculate weak similarities
    weak_similar (list,same) ;
    print_map (list,same,2) ;

    return 0;
}



void print_map (char item[MAX_ELEM][STR_LEN],int map[MAX_ELEM][MAX_ELEM], int param)
{
    // fill here
}

void strong_similar (char list[MAX_ELEM][STR_LEN], int map[MAX_ELEM][MAX_ELEM])
{
    // fill here
}


void weak_similar (char list[MAX_ELEM][STR_LEN],int map[MAX_ELEM][MAX_ELEM])
{
    // fill here
}


