#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void searchKeyword(const char * nameList[], int n, const char keyword[])
{
    // To be written
}

int main()
{
    char p1[] = "zoe_bale";
    char p2[] = "sam_rodriguez";
    char p3[] = "jack_alonso";
    char p4[] = "david_studi";
    char p5[] = "denzel_feldman";
    char p6[] = "james_bale";
    char p7[] = "james_willis";
    char p8[] = "michael_james";
    char p9[] = "dustin_bale";

    const char * nameList[9] = {p1, p2, p3, p4, p5, p6, p7, p8, p9};

    char keyword[100];
    printf("Enter a keyword: ");
    scanf("%s", keyword);

    printf("\n");

    searchKeyword(nameList, 9, keyword);

    printf("\n");
    for (int i = 0; i < 9; i++)
        printf("%s\n",nameList[i]);

    return 0;
}
