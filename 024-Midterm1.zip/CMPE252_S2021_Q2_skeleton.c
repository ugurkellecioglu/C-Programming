#include <stdio.h>
#include <math.h>

#define SIZE 500

// Read numbers from the standard input into arr
// Store number of elements in memory cell pointed to by nPtr
void readInput(int arr[], int *nPtr);

// Prints elements in arr[0..(n-1)]
void printNumbers(const int arr[], int n);

void mergeTwoArrays(const int arr1[], const int arr2[], int arr3[], int n1, int n2, int *n3p);

int main()
{
    int arr1[SIZE], arr2[SIZE], arr3[SIZE];
    int n1, n2, n3;

    printf("First array:\n");
    readInput(arr1, &n1);
    printNumbers(arr1, n1);

    printf("\nSecond array:\n");
    readInput(arr2, &n2);
    printNumbers(arr2, n2);

    mergeTwoArrays(arr1, arr2, arr3, n1, n2, &n3);

    printf("\nMerged array:\n");
    printNumbers(arr3, n3);

    return 0;
}

void readInput(int arr[], int *nPtr)
{
    printf("Number of elements: ");
    scanf("%d", nPtr);
    printf("Enter %d elements:\n", *nPtr);
    for (int i = 0; i < *nPtr; i++)
    {
        scanf("%d", &arr[i]);
    }
}

void printNumbers(const int arr[], int n)
{
    printf("Array elements:");
    for (int i = 0; i < n; i++)
    {
        printf(" %d", arr[i]);
    }
    printf("\n");
}

void mergeTwoArrays(const int arr1[], const int arr2[], int arr3[], int n1, int n2, int *n3p)
{
    // fill here
}
