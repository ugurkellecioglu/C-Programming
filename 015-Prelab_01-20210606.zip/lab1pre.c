#include <stdio.h>

void readPointsFindBoundingBox(double *bottomLeftX, double *bottomLeftY, double *widthp, double *heightp)
{
    // Your code comes here
}

int main()
{
    double bottomLeftX, bottomLeftY, width, height;

    readPointsFindBoundingBox(&bottomLeftX, &bottomLeftY, &width, &height);

    printf("Bounding box\n");
    printf("Bottom-left corner: (%.2f %.2f)\n", bottomLeftX, bottomLeftY);
    printf("Width: %.2f\n", width);
    printf("Height: %.2f\n", height);

    return 0;
}
