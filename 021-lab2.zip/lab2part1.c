#include <stdio.h>
#define SIZE 500

// reads numbers from the standard input into arr,
// and stores the number of read elements in the memory cell pointed to by nPtr
void readInput(int arr[], int *nPtr);

// prints the elements in arr[0..(n-1)]
void printNumbers(const int arr[], int n);

// Circularly shift elements of arr from left to right where last element of arr is
// shifted the first position of arr.
// Size of arr is n.
void circularShiftFromLeftToRight(int arr[], int n);


int main()
{
    int arr[SIZE];
    int n;
    readInput(arr, &n);
    printNumbers(arr, n);
    circularShiftFromLeftToRight(arr, n);
    printf("\nAfter one circular shift from left to right:\n");
    printNumbers(arr, n);
    return 0;
}

void readInput(int arr[], int *nPtr)
{
    // fill here
}

void printNumbers(const int arr[], int n)
{
    // fill here
}

void circularShiftFromLeftToRight(int arr[], int n)
{
    // fill here
}
