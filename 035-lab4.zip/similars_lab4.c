//
//  main.c
//  ted_lab4
//
//  Created by Kasim Oztoprak on 17.05.2021.
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define STR_LEN 20
#define MAX_ELEM 10
#define HASHSIZE 1000

typedef struct {  char *name;
                  char *lastname;
                  char name_lastname[STR_LEN];
                  long int strong_hash;
                  long int weak_hash[2];
                } Student;

unsigned int hash_text (char * list);
void strong_similar (Student studentList[MAX_ELEM], unsigned int map[MAX_ELEM][MAX_ELEM]);
void weak_similar (Student studentList[MAX_ELEM], unsigned int map[MAX_ELEM][MAX_ELEM]);


int main()
{
        unsigned int same[MAX_ELEM][MAX_ELEM];

        Student studentList[MAX_ELEM] = {
        { "ahmet","yuksel", 0, 0},
        { "mehmet","arslan", 0, 0},
        { "mustafa","kemal", 0, 0},
        { "ali","kemal", 0, 0},
        { "mustafa","kemal", 0, 0},
        { "mustafa","kemal", 0, 0},
        { "mehmet","arslan", 0, 0},
        { "kemal","ahmet", 0, 0},
        { "ali","kaan", 0, 0},
        { "kemal","kaan", 0, 0},
      };


        for (int i = 0; i < 10; i++)
        {
          strcpy(studentList[i].name_lastname, studentList[i].name);
          strcat(studentList[i].name_lastname, " ");
          strcat(studentList[i].name_lastname, studentList[i].lastname);
          studentList[i].strong_hash = hash_text(studentList[i].name_lastname);
        }

        strong_similar (studentList, same);

        printf("\nelements with hash values and similarities:\n");
        for (int i = 0; i < 10; i++)
        {
            printf("\n%-20s %5ld",studentList[i].name_lastname, studentList[i].strong_hash);
                for (int j=0; j<MAX_ELEM; j++)
                        if (same[i][j] ==1)
                            printf ("%4d",j);
        }

        printf ("\n");

        weak_similar (studentList, same);

        printf("\n\nelements with weak similarities:");
        for (int i = 0; i < 10; i++)
        {
                printf("\n%-20s %5ld",studentList[i].name_lastname, studentList[i].strong_hash);
                for (int j=0; j<MAX_ELEM; j++)
                        if (same[i][j] ==2)
                                printf ("%4d",j);
        }

        printf ("\n");
        return 0;
}


unsigned int hash_text (char * list)
{
    //your codes come here
}

void strong_similar (Student studentList[MAX_ELEM], unsigned int map[MAX_ELEM][MAX_ELEM])
{
    //your codes come here
}


void weak_similar (Student studentList[MAX_ELEM], unsigned int map[MAX_ELEM][MAX_ELEM])
{
    //your code come here
}
