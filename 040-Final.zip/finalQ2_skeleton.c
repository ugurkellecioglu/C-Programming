//
//  main.c
//  Ted_final
//
//  Created by Kasim Oztoprak on 6.06.2021.
//

#include <stdio.h>
#include <string.h>   // strlen
#include <stdlib.h>   // atoll or atoi - you can convert it at once by atoll or in a loop by atoi, atoll converts string into long long int similar to atoi where you convert a string to integer

#define LENGTH 11

void tckimlik_convert (char * number, short digits[]) ;
short tckimlik_check (short digits[]) ;

int main() {

    char number[LENGTH+1] ;
    short digits[LENGTH] ;

    printf ("Enter a valid TcKimlik Number: ") ;
    scanf("%s",number) ;

    tckimlik_convert (number,digits) ;

    for (int i = 0; i <  LENGTH;  i++)
        printf("%d ",digits[i]);
    printf ("\nResult: %d\n",tckimlik_check (digits)) ;
    return 0;
}



short tckimlik_check (short digits[])
{
    // fill here
}


void tckimlik_convert (char * num, short digits[])
{
    // fill here
}
