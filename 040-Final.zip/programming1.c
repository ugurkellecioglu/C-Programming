#include <stdio.h>int size(const char* file);int main ()
	{	FILE *fptr;	int a;	fptr= fopen (“file1.txt”, “w”);	//	Please write your code here	//	}

