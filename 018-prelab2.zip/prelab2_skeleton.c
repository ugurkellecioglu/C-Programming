#include <stdio.h>
#include <stdlib.h>
#define SIZE 1000

void readInput(int arr[], int *nPtr)
{
    // fill here
}

void printNumbers(const int arr[], int n)
{
    // fill here
}

void swap(int *xPtr, int *yPtr)
{
    // fill here
}

int main()
{
    int arr[SIZE];
    int array_size;
    readInput(arr, &array_size);
    int first_index = 0;
    int second_index = 0;
    printNumbers(arr, array_size);
    printf("Enter the first index to be swapped: \n");
    scanf("%d", &first_index);
    printf("Enter the second index to be swapped: \n");
    scanf("%d", &second_index);
    swap(&arr[first_index], &arr[second_index]);
    printNumbers(arr, array_size);

    return 0;
}