#include <stdio.h>
#include <math.h>

void readPointsFindMinMaxTotalLineLength(double *minLengthp, double *maxLengthp, double *totalLengthp)
{
    // your code comes here
}

int main()
{
    double minLength, maxLength, totalLength;

    readPointsFindMinMaxTotalLineLength(&minLength, &maxLength, &totalLength);

    printf("Total length of line segments %.2f\n", totalLength);
    printf("Minimum length of line segments %.2f\n", minLength);
    printf("Maximum length of line segments %.2f\n", maxLength);

    return 0;
}
